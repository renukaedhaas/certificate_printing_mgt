import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planters',
  templateUrl: './planters.component.html',
  styleUrls: ['./planters.component.css']
})
export class PlantersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
