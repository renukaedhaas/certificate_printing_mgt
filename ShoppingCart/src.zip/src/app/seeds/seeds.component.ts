import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seeds',
  templateUrl: './seeds.component.html',
  styleUrls: ['./seeds.component.css']
})
export class SeedsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
