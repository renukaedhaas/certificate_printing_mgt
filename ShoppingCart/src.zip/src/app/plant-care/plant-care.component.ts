import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plant-care',
  templateUrl: './plant-care.component.html',
  styleUrls: ['./plant-care.component.css']
})
export class PlantCareComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
